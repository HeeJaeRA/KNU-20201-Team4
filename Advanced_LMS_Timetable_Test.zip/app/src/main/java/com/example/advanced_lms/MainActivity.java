package com.example.advanced_lms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.icu.text.Transliterator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView selected_item_textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);

        GridView gridView = findViewById(R.id.grid_timetable);

        GridListAdapter adapter = new GridListAdapter();


        for(int i = 1; i <=50 ; i++){
            if(adapter.getCount()%6 == 0){
                adapter.addItem(new ListItem("A"+ (i/6),(i/6+8) + ":00" + "~" +  (i/6+8) + ":30"));
            }
            else
                adapter.addItem(new ListItem("과목이름1","0800-0900"));
        }
//        adapter.addItem(new ListItem("과목이름1","0800-0900"));
//        adapter.addItem(new ListItem("과목이름2","0800-0900"));
//        adapter.addItem(new ListItem("과목이름3","0800-0900"));
//        adapter.addItem(new ListItem("과목이름4","0800-0900"));
//        adapter.addItem(new ListItem("과목이름5","0800-0900"));
//        adapter.addItem(new ListItem("과목이름6","0800-0900"));
//        adapter.addItem(new ListItem("과목이름7","0800-0900"));
//        adapter.addItem(new ListItem("과목이름8","0800-0900"));
//        adapter.addItem(new ListItem("과목이름9","0800-0900"));
//        adapter.addItem(new ListItem("과목이름10","0800-0900"));
//        adapter.addItem(new ListItem("과목이름11","0800-0900"));
//        adapter.addItem(new ListItem("과목이름12","0800-0900"));
//        adapter.addItem(new ListItem("과목이름13","0800-0900"));
//        adapter.addItem(new ListItem("과목이름14","0800-0900"));

        gridView.setAdapter(adapter);

        WebLogic w = new WebLogic("id", "pw"); // id , password
        w.attemptLogin();
    }
}
